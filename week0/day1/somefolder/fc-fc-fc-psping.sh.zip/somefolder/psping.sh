#! /usr/bin/bash

#SAMUEL FRIMPONG
#PSPING
#It checks periodically if a specific executable has a
#live process
#It follows exactly the synopsis below
#psping [-c ###] [-t ###] [-u user-name] [-v] exe-name


#enable executability: chmod 777 psping.sh

#E.g. ./psping.sh chrome
#would ping the process "chrome" every 1 second forever

# ./psping.sh code -t 3 -c 10 -u jxtsamfrimpong
#would ping and tell the number of vscode instances run by the user jxtsamfrimpong
#every 3 seconds, continuosly for 10 times  

#It counts and echos number of live processes for a user, whose executable file is exe-name.
#It repeats this every second indefinitely, unless passed other specifications using switches:
#-c - limit amount of pings, e.g. -c 3. Default is infinite
#-t - define alternative timeout in seconds, e.g. -t 5. Default is 1 sec
#-u - define user to check process for. Default is ANY user
#-v - verbose mode, for debugging

#Feel free to edit the file for your specific needs


# GETFLAGOPTS(){
    
# }
let verbose=0
#verbose for debugging
while getopts 'c:t:u:v' OPTION;
do
    case "$OPTION" in

    c)
        let cvalue=$OPTARG
        #echo $cvalue
        ;;

    t)
        let tvalue=$OPTARG
        #echo $tvalue
        ;;

    u)
        uvalue=$OPTARG
        #echo "u option flag $OPTARG, uvalue $uvalue"
        ;;

    v)
        let verbose=1
        ;;
    
    ?)
        #echo "Invalid Flags"
        echo "Usage: psping [-c ###] [-t ###] [-u user-name] exe-name"
        exit 1
        ;;

    esac
done
shift "$(($OPTIND -1))"
#GETFLAGOPTS
#echo "c - value $cvalue"


#C_VALUE
if [[ $cvalue =~ ^[+-]?[0-9]+$ ]] # [ $cvalue -z ]
then
    if [ $verbose -eq 1 ]
    then
        echo "c is an integer"
    fi
    if ! [ $cvalue -gt 0 ];
    then
        if [ $verbose -eq 1 ]
        then
            echo "cvalue was not greater than zero"
        fi
        let cvalue=10
        let cgiven=0
        if [ $verbose -eq 1 ]
        then
            echo $cgiven
        fi
    else
        let cvalue=$cvalue
        let cgiven=1
        if [ $verbose -eq 1 ]
        then
            echo "c was greater than zero"
            echo $cgiven
        fi
    fi
else
    if [ $verbose -eq 1 ]
    then
        echo "c wasnt an integer"
    fi

    let cvalue=10
    let cgiven=0
fi

if [ $cgiven -eq 1 ];
then
    if [ $verbose -eq 1 ]
    then
        echo 'c was given'
    fi
else
    if [ $verbose -eq 1 ]
    then
        echo 'c wasnt given'
    fi
fi


#T-VALUE
if [[ $tvalue =~ ^[+-]?[0-9]+$ ]] # [ $tvalue -z ]
then
    if [ $verbose -eq 1 ]
    then
        echo "t is an integer $tvalue"
    fi

    if ! [ $tvalue -gt 0 ];
    then
        if [ $verbose -eq 1 ]
        then
            echo "tvalue was not greater than zero $tvalue"
        fi

        let tvalue=1
    else
        let tvalue=$tvalue
        if [ $verbose -eq 1 ]
        then
            echo "t was greater than zero $tvalue"
        fi
    fi
else
    if [ $verbose -eq 1 ]
    then
        echo "t wasnt an integer $tvalue"
    fi

    let tvalue=1
fi


#U-VALUE
if ! [ -z $uvalue ]; #check to see if empty
then
    if [ $verbose -eq 1 ]
    then
        echo "u not empty $uvalue"
    fi
    
    if ! [ $(cat /etc/passwd | grep -c $uvalue) -gt 0 ];
    then
        echo "given user doesn't exist in system"
        exit 1
    fi
    let ugiven=1
    if [ $verbose -eq 1 ]
    then
        echo "ugiven $ugiven"
    fi
else
    if [ $verbose -eq 1 ]
    then
        echo "u was empty $uvalue"
    fi
    let ugiven=0
    if [ $verbose -eq 1 ]
    then
        echo "ugiven $ugiven"
    fi
fi


if [ $verbose -eq 1 ]
then
    echo "flags: c - $cvalue t - $tvalue u - $uvalue c-g : $cgiven args - $@"
fi


until [ $cvalue -eq 0 ]
    do
        # if [ $? -eq 1 ];
        # then
        #     exit 1
        # fi
        #echo "doing something ...$1"

        if [ $ugiven -eq 1 ];
        then
            #let CNT=$(ps ax -u $uvalue | grep -c "$1")-3
            let CNT=$(pgrep -u $uvalue $1 | grep -c "")
            echo "$1: $CNT instances(s) ..." 
        else
            #let CNT=$(ps aux | grep -c "$1")-3
            let CNT=$(pgrep $1 | grep -c "")
            echo "$1: $CNT instances(s) ..."
        fi



        let cvalue=$cvalue-1
        if [ $cgiven -eq 0 ]
            then
                let cvalue=$cvalue+1
        fi
        sleep $tvalue
    done

if [ $verbose -eq 1 ]
then
    echo "tadaa"
fi
#ps -aux -U | grep -h "" | awk '{print $1 " " $11}'
#ps ax -u $USER | grep -c 'manager'