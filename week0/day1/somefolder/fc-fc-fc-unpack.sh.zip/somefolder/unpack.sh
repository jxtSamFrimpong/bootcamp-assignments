#! /usr/bin/bash

#SAMUEL FRIMPONG
#UNPACK
#unpack  can unpack multiple packed files (a.k.a “archives”),
#and even traverse folders recursively and unpack all archives in them - regardless of the
#specific algorithm that was used when packing them

#It follows exactly the synopsis below
#unpack [-r] [-v] file [file...]

#enable executability: chmod +x unpack.sh

#E.g. ./unpack.sh welcome.zip 
#would unzip welcome.zip
# ./unpack.sh -r -v *
#would decompress all archives in current directory and subdirectories,
#it will also gove success and warning messages

#Given a list of filenames as input, this script queries each target file (parsing the output of the
#file command) for the type of compression used on it. Then the script automatically invokes
#the appropriate decompression command, putting files in the same folder. If files with the
#same name already exist, they are overwritten.
#Unpack supports 4 unpacking options - gunzip, bunzip2, unzip, uncompress.
#Additional switches:
#-v - verbose - echo each file decompressed & warn for each file that was NOT
#decompressed
#-r - recursive - will traverse contents of folders recursively, performing unpack on each.


let FAILURES=0
let DECOMPRESSED=0
let VERBOSE=0
let RECURSIVE=0
while getopts 'rv' OPTION;
do
    case "$OPTION" in

    r)
        let RECURSIVE=1
        #echo $RECURSIVE
        ;;

    v)
        let VERBOSE=1
        #echo $VERBOSE
        ;;
    
    ?)
        #echo "Invalid Flags"
        echo "Usage: unpack [-r] [-v] file [file...]"
        exit 1
        ;;

    esac
done
shift "$(($OPTIND -1))"
#echo $RECURSIVE
#echo $VERBOSE
let SING_FOL=$#
#echo $@

CHECK_FOR_CLI_DEP(){
    Z7_EXISTS=$(which 7z | grep -c "usr")
    # UNZIP_EXITS=$(which unzip | grep -c "usr")
    # UNCOMPRESS_EXISTS=$(which uncompress | grep -c "usr")
    # BUNZIP2_EXISTS=$(which bunzip2 | grep -c "usr")
    # GUNZIP_EXISTS=$(which gunzip | grep -c "usr")

    # if ! [ UNZIP_EXITS -eq 1 ]
    # then
    #     sudo apt install p7zip-full p7zip-rar
    # fi

    if ! [ $Z7_EXISTS -eq 1 ]
    then
        #echo "installing 7z ..."
        sudo apt update
        sudo apt install p7zip-full p7zip-rar
    fi

}

CHECK_FOR_CLI_DEP

DIRECTORY_TREATMENT(){
    #echo $SING_FOL $RECURSIVE
    let SOME="$RECURSIVE + $SING_FOL"
    #echo "first some $SOME sing $SING_FOL rec $RECURSIVE"
    # if  (( $RECURSIVE == 1  ||  $SING_FOL == 1 ))
    if [ $SOME -gt 0 ]
    then
        SING_FOL=0
        #echo "do smfn for $1 folder"
        #FOLDER_SEARCH_OUT=$(file -i $1/* | grep -h ":")
        #FOLDER_SEARCH_OUT=$(ls -h $1/ )

        for i in "$1"/*
        do
            #echo    "things in subdir $i"
            UNARCHIVE "$i"
            #echo "second some $SOME sing $SING_FOL rec $RECURSIVE"
            #echo "sig $SING_FOL rec $RECURSIVE"
        done
    else
        let FAILURES=$FAILURES+1
    fi
}

UNARCHIVE(){
    #echo "archive recieved $#"
    NAME=$@
    #echo "name $NAME"
    IS_DIRECTORY=$(file -i "$NAME" | grep -c "inode/directory")
    #file -i "$NAME"
    if ! [ $IS_DIRECTORY -eq 1 ]
    then
        #echo "check archive format and unarchive arcordinly"
        #if .zip
        if [ $(file -i "$NAME" | grep -c "application/zip") -eq 1 ]
        then
            #echo "its a .zip so open with zips"
            if [ $VERBOSE -eq 1 ]
            then
                echo "Unpacking $NAME..."
            fi
            TERM_OUTPUT=$(7z x "$NAME" -aoa -o~)
            IS_OK=$(echo $TERM_OUTPUT | grep -c "Everything is Ok")
            #echo "IS OK $IS_OK"
            if [ $IS_OK -eq 1 ]
            then
                let DECOMPRESSED=$DECOMPRESSED+1
            else
                let FAILURES=$FAILURES+1
                if [ $VERBOSE -eq 1 ]
                then
                    echo "Failed to unpack $NAME"
                fi
            fi
            
            #grep out put for everything is ok
            #Everything is Ok
            #echo $TERM_OUTPUT
        elif [ $(file -i "$NAME" | grep -c "application/x-compress") -eq 1 ]
        then
            #echo "uncompress xcompress"
            if [ $VERBOSE -eq 1 ]
            then
                echo "Unpacking $NAME..."
            fi
            TERM_OUTPUT=$(7z x "$NAME" -aoa -o~)
            IS_OK=$(echo $TERM_OUTPUT | grep -c "Everything is Ok")
            #echo "IS OK $IS_OK"
            if [ $IS_OK -eq 1 ]
            then
                let DECOMPRESSED=$DECOMPRESSED+1
            else
                let FAILURES=$FAILURES+1
                if [ $VERBOSE -eq 1 ]
                then
                    echo "Failed to unpack $NAME"
                fi
            fi

        elif [ $(file -i "$NAME" | grep -c "application/x-bzip2") -eq 1 ]
        then
            #echo "uncompress application/x-bzip2"
            if [ $VERBOSE -eq 1 ]
            then
                echo "Unpacking $NAME..."
            fi
            TERM_OUTPUT=$(7z x "$NAME" -aoa -o~)
            IS_OK=$(echo $TERM_OUTPUT | grep -c "Everything is Ok")
            #echo "IS OK $IS_OK"
            if [ $IS_OK -eq 1 ]
            then
                let DECOMPRESSED=$DECOMPRESSED+1
            else
                let FAILURES=$FAILURES+1
                if [ $VERBOSE -eq 1 ]
                then
                    echo "Failed to unpack $NAME"
                fi
            fi

        elif [ $(file -i "$NAME" | grep -c "application/gzip") -eq 1 ]
        then
            #echo "uncompress application/gzip"
            if [ $VERBOSE -eq 1 ]
            then
                echo "Unpacking $NAME..."
            fi
            TERM_OUTPUT=$(7z x "$NAME" -aoa -o~)
            IS_OK=$(echo $TERM_OUTPUT | grep -c "Everything is Ok")
            #echo "IS OK $IS_OK"
            if [ $IS_OK -eq 1 ]
            then
                let DECOMPRESSED=$DECOMPRESSED+1
            else
                let FAILURES=$FAILURES+1
                if [ $VERBOSE -eq 1 ]
                then
                    echo "Failed to unpack $NAME"
                fi
            fi

        else
            #echo "none of the supported filetypes"
            if [ $VERBOSE -eq 1 ]
            then
                echo "Ignoring $NAME"
            fi
            let FAILURES=$FAILURES+1

        fi
    else
        #echo "give directory treatment"
        DIRECTORY_TREATMENT "$NAME"
    fi   
}
#sudo 7z x 1.zip -o"~"


CHECK_FOR_ARG_NUM(){
    #echo "arguments recieved $#"
    if [ $# -eq 1 ]
    then
        #echo "just one file"
        UNARCHIVE "$1"
        #echo "$1"
    else
        #echo "group of files and folders"
        #echo "$@"
        for F_ in "$@"
        do
           # echo "$F_"
            CHECK_FOR_ARG_NUM "$F_"
        done
    fi
}


CHECK_FOR_ARG_NUM "$@"


echo "Decompressed $DECOMPRESSED archive(s)"
exit $FAILURES
